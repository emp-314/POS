-- Upsert admin user with password 'admin123'
-- Uses bcrypt hash (10 rounds). If you want a different password, replace the hash.

INSERT INTO users (username, email, password, role, active)
VALUES
  ('admin', 'admin@possystem.com', '$2b$10$YJVGZfzJvvYnB.q2kJqkNu0QzQ2q/25K2qd3L6m3D7K5A1KqKQPym', 'admin', 1)
ON DUPLICATE KEY UPDATE
  email = VALUES(email),
  password = VALUES(password),
  role = VALUES(role),
  active = VALUES(active);

-- Verify
SELECT user_id, username, email, role, active FROM users WHERE username = 'admin';
